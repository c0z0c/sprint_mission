# Evaluation with test datasets
MODE=test
MODEL_PATH="../models/MultiSumAbs_thesis_1024"
DATA_PATH="../bert_data/thesis"

python train.py \
	-task abs \
	-mode $MODE \
	-test_all False \
	-test_from ${MODEL_PATH}/model_step_200000.pt \
	-batch_size 3000 \
	-test_batch_size 3000 \
	-bert_data_path ${DATA_PATH} \
	-log_file ../logs/MultiSumAbs_thesis_1024 \
	-model_path ${MODEL_PATH} \
	-sep_optim true \
	-use_interval true \
	-visible_gpus 0 \
	-max_pos 1024 \
	-max_length 200 \
	-alpha 0.95 \
	-min_length 8 \
	-result_path ../logs/ \
	-tokenizer multi \
	-tgt_bos [unused1] \
	-tgt_eos [unused2] \
	-tgt_sent_split [unused3] \
	-beam_size 5

