# Train model
MODEL_PATH="../models/MultiSumAbs_thesis_1024"
DATA_PATH="../bert_data/thesis"
python train.py \
	-task abs \
	-mode train \
	-model_path $MODEL_PATH \
	-result_path ../results/ \
	-bert_data_path $DATA_PATH \
	-dec_dropout 0.2 \
	-sep_optim true \
	-lr_bert 0.002 \
	-lr_dec 0.2 \
	-save_checkpoint_steps 5000 \
	-batch_size 200 \
	-train_steps 200000 \
	-report_every 50 \
	-accum_count 5 \
	-use_bert_emb true \
	-use_interval true \
	-warmup_steps_bert 20000 \
	-warmup_steps_dec 10000 \
	-max_pos 1024 \
	-visible_gpus 0,1,2 \
	-log_file ../logs/MultiSumAbs \
	-tokenizer multi \
	-tgt_bos [unused1] \
	-tgt_eos [unused2] \
	-tgt_sent_split [unused3]

