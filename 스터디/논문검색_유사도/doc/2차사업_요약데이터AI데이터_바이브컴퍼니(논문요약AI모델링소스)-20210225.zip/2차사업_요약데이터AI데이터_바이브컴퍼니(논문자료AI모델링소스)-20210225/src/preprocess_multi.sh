# Clean data & Split sentences
RAW_PATH="../sample_data/thesis_50"
SAVE_PATH="../json_data"
python prepro/split_sentence.py \
	-raw_path $RAW_PATH \
	-save_path $SAVE_PATH \
	-save_pattern thesis.train.{}.json \
	-data_type thesis \
	-chunk_size 1000 \
	-clean_data False \
	-n_cpus 15

# Split valid and test data
for i in {0..15}
do
	mv ../json_data/thesis.train.${i}.json ../json_data/thesis.valid.${i}.json
done

for i in {16..31}
do
	mv ../json_data/thesis.train.${i}.json ../json_data/thesis.test.${i}.json
done

# Tokenizing & Format to PyTorch files
RAW_PATH="../json_data"
SAVE_PATH="../bert_data"
PLM_PATH="../../PLM"
python preprocess.py \
	-mode format_to_bert \
	-raw_path $RAW_PATH \
	-save_path $SAVE_PATH \
	-n_cpus 15 \
	-log_file ../logs/preprocess.log \
	-tokenizer multi \
	-tgt_bos [unused1] \
	-tgt_eos [unused2] \
	-tgt_sent_split [unused3]
